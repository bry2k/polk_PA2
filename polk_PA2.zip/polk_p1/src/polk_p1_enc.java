import java.util.Scanner;
public class polk_p1_enc
{
	static Scanner kb = new Scanner(System.in);
	public static void main(String[] args)
	{
		int[] sepNum = getInput();
		encryptAndPrint(sepNum);
	}
	
	public static int[] getInput()
	{
		int[] sepNum = new int[4];
		System.out.println("Please enter a 4 digit integer to be sent.");
		String userIn = kb.next();
		try {
			int num = Integer.parseInt(userIn);
			if(num > 9999 || num < 0)
			{
				System.out.println("Invalid input. Exiting encryption software.");
				System.exit(0);
			}
			else
			{
				if(num > 999)
				{
					for(int i = sepNum.length - 1; i > -1; i--)
					{
						sepNum[i] = num % 10;
						num = num/10;
					}
				}
				else if (num > 99)
				{
					sepNum[0] = 0;
					for(int i = sepNum.length - 1; i > -1; i--)
					{
						sepNum[i] = num % 10;
						num = num / 10;
					}
				}
				else if (num > 9)
				{
					sepNum[0] = 0;
					sepNum[1] = 0;
					sepNum[3] = num % 10;
					num = num/10;
					sepNum[2] = num % 10;
				}
				else
				{
					sepNum[0] = 0;
					sepNum[1] = 0;
					sepNum[2] = 0;
					sepNum[3] = num;
				}
			}
		}
		catch(NumberFormatException e)
		{
			System.out.println("Invalid input. Exiting encryption software.");
			System.exit(0);
		}
		return sepNum;
	}
	public static void encryptAndPrint(int[] sepNum)
	{
		for(int i = 0; i < sepNum.length; i++)
		{
			sepNum[i] = (sepNum[i] + 7) % 10;
		}
		int temp = sepNum[0];
		sepNum[0] = sepNum[2];
		sepNum[2] = temp;
		temp = sepNum[1];
		sepNum[1] = sepNum[3];
		sepNum[3] = temp;
		System.out.println();
		for(int i = 0; i < sepNum.length; i++)
		{
			System.out.print(sepNum[i]);
		}
		
	}
}
