import java.util.Scanner;
public class polk_p2 
{
	static Scanner kb = new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Would you like to use pounds and inches or kilograms and meters?");
		System.out.println("Type 1 for pounds and inches, or 2 for kilograms and meters.");
		int choice = kb.nextInt();
		if(choice == 1)
		{
			System.out.println("Please enter your weight in pounds.");
			double weight = kb.nextDouble();
			System.out.println("Please enter your height in inches.");
			double height = kb.nextDouble();
			System.out.println("Your BMI is " + calcBMIpi(weight, height));
			System.out.println("BMI Categories:\nUnderweight < 18.5\nNormal Weight 18.5-24.9\nOverweight 25-29.9\nObesity > 30");
		}
		else if(choice == 2)
		{
			System.out.println("Please enter your weight in kilograms.");
			double weight = kb.nextDouble();
			System.out.println("Please enter your height in meters.");
			double height = kb.nextDouble();
			System.out.println("Your BMI is " + calcBMIkm(weight, height));
			System.out.println("BMI Categories:\nUnderweight < 18.5\nNormal Weight 18.5-24.9\nOverweight 25-29.9\nObesity > 30");
		}
		else
		{
			System.out.println("Invalid choice, exiting.");
			System.exit(0);
		}
	}
	public static double calcBMIpi(double weight, double height)
	{
		double bmi = weight*703/height/height;
		return bmi;
	}
	public static double calcBMIkm(double weight, double height)
	{
		double bmi = weight/height/height;
		return bmi;
	}
}
