import java.util.Scanner;
public class polk_p3 
{
	static Scanner kb = new Scanner(System.in);
	static String[] topics = new String[5];
	static int[][] responses = new int[5][10];
	public static void main(String[] args)
	{
		for(int i = 0; i < 5; i++)
		{
			for(int j = 0; j < 10; j++)
			{
				responses[i][j] = 0;
			}
		}
		topics[0] = "World of Warcraft";
		topics[1] = "League of Legends";
		topics[2] = "Warframe";
		topics[3] = "Minecraft";
		topics[4] = "Dauntless";
		boolean check = true;
		while(check)
		{
			System.out.println("Please rate following video games on a scale of 1 to 10.");
			for(int i = 0; i < 5; i++)
			{
				System.out.println(topics[i]);
				int score = kb.nextInt();
				if(score > 0 && score < 11)
				{
					responses[i][score-1]++;
				}
				else
				{
					System.out.println("Invalid input. exiting.");
					System.exit(0);
				}
				
			}
			System.out.println("Would another person like to take the survey? Enter 1 if so.");
			int choice = kb.nextInt();
			if(choice != 1)
			{
				check = false;
			}
		}
		int minAvg = 0;
		int maxAvg = 0;
		int pointTotalMin = 0;
		int pointTotalMax = 0;
		double mxAvg = 0;
		double mnAvg = 10000000;
		for(int r = 0; r < responses.length; r++)
		{
			double avg = 0;
			int count = 0;
			
			
			if(r < 2)
				System.out.print(topics[r]+"\t");
			else
				System.out.print(topics[r]+"\t\t");
			for(int c = 0; c < responses[r].length; c++)
			{
				System.out.print(responses[r][c] + " ");
				if(responses[r][c] > 0)
				{
					while(responses[r][c] > 0)
					{
						responses[r][c]--;
						count++;
						avg += c+1;
					}
					responses[r][c] += count;
				}
			}
			avg = avg/count;
			System.out.println("Average: " + avg);
			if(avg > mxAvg)
			{
				mxAvg = avg;
				maxAvg = r;
			}
			if(avg < mnAvg)
			{
				mnAvg = avg;
				minAvg = r;
			}
			avg = 0;
			count = 0;
		}
		
		for(int c = 0; c < responses[minAvg].length; c++)
		{
			if(responses[minAvg][c] > 0)
			{
				while(responses[minAvg][c] > 0)
				{
					pointTotalMin += c + 1;
					responses[minAvg][c] --;
				}
			}
		}
		for(int c = 0; c < responses[maxAvg].length; c++)
		{
			if(responses[maxAvg][c] > 0)
			{
				while(responses[maxAvg][c] > 0)
				{
					pointTotalMax += c + 1;
					responses[maxAvg][c] --;
				}
			}
		}
		System.out.print("The highest rated game is " + topics[maxAvg]);
		System.out.println(" and the total rating was " + pointTotalMax);
		System.out.print("The lowest rated game is " + topics[minAvg]);
		System.out.println(" and the total rating was " + pointTotalMin);
	}
}
